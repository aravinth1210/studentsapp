import React, { Component } from "react";
import '../login/login.css';
import axios from "axios";

class AdminForm extends Component {

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      password: ''
    };
    this.nameChange = this.nameChange.bind(this);
    this.passwordChange = this.passwordChange.bind(this);
  }

  nameChange(event) {
    this.setState({ name: event.target.value });
  }
  passwordChange(event) {
    this.setState({ password: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log("form has been submitted: ");
    console.log(this.state.name + " - " + this.state.password)
    axios({
      method: 'post',
      url: 'http://127.0.0.1:5000/auth',
      data: {
        username: this.state.name,
        password: this.state.password
      }
    }).then((res) => {
      console.log(res);
      if (res.data.error)
        alert("Enter correct credentials")
      localStorage.setItem("isloogedin", "true")
      localStorage.setItem("username", res.data.username)
      window.location.href = "/admin"
    })
      .catch((err) => { console.log(err) });
    console.log(this.props)
  }


  render() {
    return (
      <div className="container">
        <div className="form-box">
          <div className="header-form">
            <h4 className="text-primary text-center"><i className="fa fa-user-circle" style={{ fontSize: "110px" }}></i></h4>
            <div className="image">
            </div>
            <h5 className="text-col">Admin Login</h5>
          </div>
          <div className="body-form">
            <form onSubmit={(e) => { this.handleSubmit(e) }}>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text"><i class="fa fa-user"></i></span>
                </div>
                <input className="form-control" placeholder="Username" type="text" value={this.state.email} onChange={(e) => { this.nameChange(e) }} />
              </div>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text"><i class="fa fa-lock"></i></span>
                </div>
                <input type="password" className="form-control" value={this.state.password} placeholder="Password" onChange={(e) => { this.passwordChange(e) }} />
              </div>
              <button type="submit" className="btn btn-secondary btn-block">LOGIN</button>
              <div className="message">
              </div>
            </form>
            <div className="social">
              <a href="https://www.facebook.com/"><i className="fab fa-facebook"></i></a>
              <a href="https://www.twitter.com/"><i className="fab fa-twitter-square"></i></a>
              <a href="https://www.google.com/"><i className="fab fa-google"></i></a>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default AdminForm;