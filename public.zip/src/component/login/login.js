import React from 'react';
import AdminForm from './adminform';
import StudentForm from './studentform';
import TeacherForm from './teacherform';
import { useState } from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
// import '../admin/subpage/app.css';


function Login() {
  const [id, setInfo] = useState('admin');

  console.log('info' + id)
  localStorage.setItem('type', id)

  return (




    <div className='bd-color'>

      <div className="with-bg-size bgs">
        <div id="color-overlay"></div>
      </div>

      <div className="login-center">
        <Box>
          <div className="pad-6">
            <input type="checkbox" value={'admin'} onChange={() => setInfo('admin')} checked={id === 'admin'} />&nbsp;<span className="titleCards">Admin</span>&nbsp;&nbsp;
            <input type="checkbox" value={'student'} onChange={() => setInfo('student')} checked={id === 'student'} />&nbsp;<span className="titleCards">Student</span>&nbsp;&nbsp;
            <input type="checkbox" value={'teacher'} onChange={() => setInfo('teacher')} checked={id === 'teacher'} />&nbsp;<span className="titleCards">Teacher</span>
          </div>
        </Box>
        <RoleInfo info={id} />
      </div>
    </div>
  )
}

const RoleInfo = (info) => {
  switch (info.info) {
    case 'admin':
      return <AdminForm />
    case 'student':
      return <StudentForm />
    case 'teacher':
      return <TeacherForm />
    default:
      break;
  }
}


export default Login;