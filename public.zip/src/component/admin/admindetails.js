import React, { Component } from 'react';
import { TweenLite, TimelineLite } from "gsap";
import { NavLink } from "react-router-dom";
// import Menu from './Menu'
import Createstudent from "./subpage/createstudent";
import Createteacher from "./subpage/createteacher";
import Createuser from "./subpage/createuser";
import Createfees from "./subpage/createfees";
import Createcourse from "./subpage/createcourse";
import Searchstudent from "./subpage/searchstudent";
import Searchteacher from "./subpage/searchteacher";
import Searchcourse from "./subpage/searchcourse";
import Searchcoursefee from "./subpage/searchfees";
import Updatestudent from "./subpage/updatestudent";
import Header from '../header/header';
// import Footer from '../footer/footer';
import '../admin/admin.css';


class Admin extends Component {



  constructor(props) {

    super(props)
    this.state = {
      elem: null,
      openVal: "False",
      mainelem: null,
      menuText: 'Click to open Menu',
      menuOpen: false


    };
    this.toggleshow = this.toggleshow.bind(this);
    this.createUserFn = this.createUserFn.bind(this);
    this.createStudentFn = this.createStudentFn.bind(this);
    this.createTeacherFn = this.createTeacherFn.bind(this);
    this.createCourseFn = this.createCourseFn.bind(this);
    this.createCourseFeeFn = this.createCourseFeeFn.bind(this);
    this.searchStudentFn = this.searchStudentFn.bind(this);
    this.searchTeacherFn = this.searchTeacherFn.bind(this);
    this.searchCourseFn = this.searchCourseFn.bind(this);
    this.searchCourseFeeFn = this.searchCourseFeeFn.bind(this);
    this.updateStudentFn = this.updateStudentFn.bind(this);


    this.drawer = null;
    this.menuBtn = null;
    this.contentVeil = null;

    this.drawerTween = new TimelineLite({
      paused: true
    });

    this.toggleContentVeil = this.toggleContentVeil.bind(this);
    this.toggleDrawer = this.toggleDrawer.bind(this);
    this.veilClickHandler = this.veilClickHandler.bind(this);
  }

  componentDidMount() {
    console.log(localStorage.getItem('username'))
    console.log(localStorage.getItem("isloogedin"))
    if (localStorage.getItem("isloogedin") != "true") {
      window.location.href = "Login"
    }
    this.createUserFn();
  }

  logoutonClick() {
    localStorage.clear();
    window.location.href = "Login"
}

  toggleContentVeil() {
    TweenLite.set(this.contentVeil, {
      autoAlpha: this.drawerTween.reversed() ? 0 : 0.25
    });
  }

  toggleDrawer() {
    this.drawerTween.reversed(!this.drawerTween.reversed());
    this.setState({
      menuOpen: !this.state.menuOpen
    });
  }

  veilClickHandler(e) {
    e.stopPropagation();
    this.toggleDrawer();
  }


  toggleshow() {
    console.log("Menu clicked")
    if (this.state.openVal == "False") {
      this.setState({ openVal: 'True' })
      this.setState({ menuText: 'Click here to Close Menu' })
      this.setState({
        elem: <div id="menubtn" className='menucon ' onClick={this.toggleshow}>
          <div onClick={this.createUserFn}>Create User</div>
          <div onClick={this.createStudentFn}>Create Student</div>
          <div onClick={this.createTeacherFn}>Create Teacher</div>
          <div onClick={this.createCourseFn}>Create Course</div>
          <div onClick={this.createCourseFeeFn}>Create CourseFee</div>
          <div onClick={this.searchStudentFn}>Search Student</div>
          <div onClick={this.searchTeacherFn}>Search Teacher</div>
          <div onClick={this.searchCourseFn}>Search Course</div>
          <div onClick={this.searchCourseFeeFn}>Search Course Fee</div>
          <div onClick={this.updateStudentFn}>Update Student</div>
        </div>
      });
    } else {
      this.setState({ elem: null })
      this.setState({ openVal: 'False' })
      this.setState({ menuText: 'Click here to Open Menu' })
    }
  }

  createUserFn() {
    this.setState({ mainelem: <div><Createuser /></div> })
  }
  createStudentFn() {
    this.setState({ mainelem: <div><Createstudent /></div> })
  }
  createTeacherFn() {
    this.setState({ mainelem: <div><Createteacher /></div> })
  }
  createCourseFn() {
    this.setState({ mainelem: <div><Createcourse /></div> })
  }
  createCourseFeeFn() {
    this.setState({ mainelem: <div><Createfees /></div> })
  }
  searchStudentFn() {
    this.setState({ mainelem: <div><Searchstudent /></div> })
  }
  searchTeacherFn() {
    this.setState({ mainelem: <div><Searchteacher /></div> })
  }
  searchCourseFn() {
    this.setState({ mainelem: <div><Searchcourse /></div> })
  }
  searchCourseFeeFn() {
    this.setState({ mainelem: <div><Searchcoursefee /></div> })
  }
  updateStudentFn() {
    this.setState({ mainelem: <div><Updatestudent /></div> })
  }



  render() {

    return (
      <div>
        <div>
          <nav className="navbar bd-col">
            <a href="#" className="navbar-logo"
            ><i class="material-icons"></i>Code<i class="fab fa-codepen"></i></a>
            <ul className="navbar-links">
              <li className="navbar-dropdown">
                <a href="#">Admin</a>
                <div className="dropdown drops">
                  <a onClick={this.createUserFn}>Create User</a>
                </div>
              </li>
              <li className="navbar-dropdown">
                <a href="#">Student</a>
                <div className="dropdown drops">
                  <a onClick={this.createStudentFn}>Create Student</a>
                  <a onClick={this.searchStudentFn}>Search Student</a>
                  <a onClick={this.updateStudentFn}>Update Student</a>
                </div>
              </li>
              <li className="navbar-dropdown">
                <a href="#">Teacher</a>
                <div className="dropdown drops">
                  <a onClick={this.createTeacherFn}>Create Teacher</a>
                  <a onClick={this.searchTeacherFn}>Search Teacher</a>
                </div>
              </li>
              <li className="navbar-dropdown">
                <a href="#">Course</a>
                <div className="dropdown drops">
                  <a onClick={this.createCourseFn}>Create Course</a>
                  <a onClick={this.searchCourseFn}>Search Course</a>
                  <a onClick={this.createCourseFeeFn}>Create CourseFee</a>
                  <a onClick={this.searchCourseFeeFn}>Search CourseFee</a>
                </div>
              </li>
            </ul>
            <ul className="navbar-links pad-l">
              <li className="navbar-dropdown">
              <NavLink to="/" onClick={this.logoutonClick} exact activeStyle={{ color: '#2a6496' }}>Logout</NavLink>
               </li>

              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4510menu-item menu-item-type-custom menu-item-object-custom menu-item-4510 gdlr-normal-menu"><a title="Facebook" href="https://www.facebook.com/Timezonehostelhollywood/"><i class="fa fa-facebook-square"></i></a></li>
              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4511menu-item menu-item-type-custom menu-item-object-custom menu-item-4511 gdlr-normal-menu"><a title="Twitter" href="https://twitter.com/timezonehostel"><i class="fa fa-twitter-square"></i></a></li>
              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4512menu-item menu-item-type-custom menu-item-object-custom menu-item-4512 gdlr-normal-menu"><a title="Instagram" href="https://www.instagram.com/Timezonehostelhollywood/"><i class="fa fa-instagram"></i></a></li>

            </ul>
          </nav>
        </div>

        <div className='admincont'>{this.state.mainelem}</div>
        {/* <Footer /> */}
      </div>
    );

  }

}






export default Admin;