import React from "react";
import '../subpage/App.css'
import axios from 'axios'; 
import swal from 'sweetalert';
import Alert from '@mui/material/Alert';
import '../subpage/createstudent.css';

const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Createstudent extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         name: '',
         studentid: '',
         course:'',
         data:[],
         coursefee:'',
         teachername:''
        };
        this.nameChange = this.nameChange.bind(this);
        this.studentidChange = this.studentidChange.bind(this);
        this.courseChange=this.courseChange.bind(this);
       
      }

      nameChange(event) {
        this.setState({ name: event.target.value});
      }
      studentidChange(event) {
        this.setState({ studentid: event.target.value});
      }
      courseChange(event) {
          console.log(event.target.value)
        this.setState({ course: event.target.value});
      }
      toggleshow() {
        
        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("ara");
      
        node.classList.remove('hide')
      }
      componentDidMount(){

        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchallstudents',  
          data: {  
           
          }  
        }).then((res) => {
          console.log(res);
          this.setState({data:res.data})
          
        })

      }

      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/savestudent',  
          data: {  
            name: this.state.name,  
            studentid: this.state.studentid,
            course: this.state.course
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
          this.componentDidMount()
          this.setState({name:''})
          this.setState({studentid:''})
          this.setState({course:''})
          swal({
            title: "Success!",
            text: "Student Created Successfully",
            icon: "success",
          });
          
        })

      
        .catch((err) => { console.log(err)});
       
      }
      onClick() {
       
        console.log()
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchteacher',  
          data: {  
            name:this.state.name ,  
            
           
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
           
            
        })
  
        
      }
      handleClick(event) {

       
        console.log('Click happened');
        console.log(event);
        localStorage.setItem('type','course')
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchteacherbycourse',  
          data: {  
            course: event,  
            
           
          }  
        }).then((res) => {
          console.log(res);
          console.log( res.data[0].name);
          this.setState({teachername: res.data[0].name});
          if(res.data.error)
            alert("Enter correct credentials")
           
            
        })

       
        .catch((err) => { console.log(err)});
       

      axios({  
        method: 'post',  
        url: 'http://127.0.0.1:5000/fetchcoursefeebycourse',  
        data: {  
          coursename:event,  
          
         
        }  
      }).then((res) => {
        console.log(res);
        console.log(res.data[0].coursefee);
        this.setState({coursefee: res.data[0].coursefee})
        if(res.data.error)
          alert("Enter correct credentials")
          console.log('as')
         
          
      })

      
      .catch((err) => { console.log(err)});
     
    console.log(this.state)
    setTimeout(() => {
      console.log('This will run after 1.5 second!')
      console.log(this.state.teachername)
      console.log(this.state.coursefee)
      swal({
        title: "View Details",
        text:"Teacher Name:"+this.state.teachername+  "    Course Fees:"+this.state.coursefee,
        icon: "info",
      });
    }, 2500);

    

    
    };



      

      render() {
          console.log(this.state)
          var that =this
        return (
            <div class='overAll'>
            
            <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
           
               <label className="lab"> Name </label>
               <div className="master-form-group">
               <input type="name" value={this.state.name} placeholder="Student name" onChange={(e)=>{this.nameChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">Student Id </label>
               <div className="master-form-group">
               <input type="studentid" value={this.state.studentid} placeholder="Studentid" onChange={(e)=>{this.studentidChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">course </label>
               <div className="master-form-group">
               <input type="course" value={this.state.course} placeholder="Course" onChange={(e)=>{this.courseChange(e)}} />
               </div>
               </div>
               </div>
               <SubmitButton />

               
             </form>
             </div>
             
             <div className="master-createuser">
        <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Course Name</th>
              <th>View</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.studentid}</td>
                  <td>{user.name}</td>
                  <td>{user.course}</td>
                 <td> <button type="submit"className="master-submit-btn" onClick={(e)=>{that.handleClick(user.course)}}>View</button></td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No Student</td>
              </tr>
            )}
          </tbody>
        </table>
        );
      </div>

             
             </div>
            

          
        );
      } 
}



export default Createstudent;