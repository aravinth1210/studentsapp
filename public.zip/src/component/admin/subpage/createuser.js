import React from "react";
import '../subpage/App.css'
import axios from 'axios';
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import DataTable from "react-data-table-component";
import '../subpage/createuser.css';



const SubmitButton = (props) => {
  return (
    <div className="master-form-group master-center">
      <button type="submit" className="master-submit-btn">Submit</button>
    </div>
  )
}



class Createuser extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      password: '',
      type: '',
      data: [],
    };
    this.nameChange = this.nameChange.bind(this);
    this.passwordChange = this.passwordChange.bind(this);
  }

  nameChange(event) {
    this.setState({ name: event.target.value });
  }
  passwordChange(event) {
    this.setState({ password: event.target.value });
  }
  typeChange(event) {
    console.log(event.target.value)
    this.setState({ type: event.target.value });
  }

  toggleshow() {
    var aknode = document.getElementsByClassName("totalhide");
    for (var i = 0; i < aknode.length; i++) {
      aknode[i].classList.add('hide')
    }

    console.log('sm')
    var node = document.getElementById("sampletest");
    node.classList.remove('hide')

  }
  componentDidMount() {
    axios({
      method: 'post',
      url: 'http://127.0.0.1:5000/fetchallusers',
      data: {
      }
    }).then((res) => {
      this.setState({ data: res.data })
    })
      .catch((err) => { console.log(err) });
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log("form has been submitted: ");
    axios({
      method: 'post',
      url: 'http://127.0.0.1:5000/saveuser',
      data: {
        username: this.state.name,
        password: this.state.password,
        type: this.state.type
      }
    }).then((res) => {
      console.log(res);
      if (res.data.error) {
        swal({
          title: "Good job!",
          text: "You clicked the button!",
          icon: "error",
        });
      }
      else {
        this.componentDidMount()
        this.setState({ name: '' })
        this.setState({ password: '' })
        this.setState({ type: '' })

        swal({
          title: "Success!",
          text: "User Created Successfully",
          icon: "success",
        });
      }


    })
      .catch((err) => { console.log(err) });
  }


  render() {
    return (

      <div class='overAll'>
        <div class="container">
          <form onSubmit={(e) => { this.handleSubmit(e) }}>
            <div class="row justify-content-center">
              <div class="col-4">
                <label className="lab">User Name</label>
                <div className="master-form-group">
                  <input type="text" value={this.state.name} placeholder="Username" onChange={(e) => { this.nameChange(e) }} />
                </div>
              </div>
              <div class="col-4">
                <label className="lab">Password</label>
                <div className="master-form-group">
                  <input type="password" value={this.state.password} placeholder="Password" onChange={(e) => { this.passwordChange(e) }} />
                </div>
              </div>
              <div class="col-4">
                <label className="lab">Type</label>
                <div className="master-form-group">
                  <input type="text" value={this.state.type} placeholder="Type" onChange={(e) => { this.typeChange(e) }} />
                </div>
              </div>
            </div>
            <SubmitButton />
          </form>
        </div>

        

       <div className="master-createuser">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.username}</td>
                  <td>{user.password}</td>
                  <td>{user.type}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table>
              
      </div>
      </div>
    );
  }
}

export default Createuser;