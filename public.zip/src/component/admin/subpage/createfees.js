import React from "react";

import '../subpage/App.css'
import axios from 'axios'; 
import swal from 'sweetalert';
import '../subpage/createfees.css';

const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Createfees extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         coursename: '',
         courseid: '',
         coursefee:'',
         data:[]
        };
        this.coursenameChange = this.coursenameChange.bind(this);
        this.courseidChange = this.courseidChange.bind(this);
        
      }

      coursenameChange(event) {
        this.setState({ coursename: event.target.value});
      }
      courseidChange(event) {
        this.setState({ courseid: event.target.value});
      }
      coursefeeChange(event) {
          console.log(event.target.value)
        this.setState({ coursefee: event.target.value});
      }
      toggleshow() {
        var aknode = document.getElementsByClassName("totalhide");
        for(var i=0;i<aknode.length;i++){
          aknode[i].classList.add('hide')
      }
         
       
        var node = document.getElementById("kar");
      
        node.classList.toggle('hide')
      }
      componentDidMount(){
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchallcoursesfee',  
          data: {  
           
          }  
        }).then((res) => {
          console.log(res);
         
            this.setState({data:res.data})
        })

       
        .catch((err) => { console.log(err)});
       
      }

      
      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
      
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/savefees',  
          data: {  
            coursename: this.state.coursename,  
            courseid: this.state.courseid,
            coursefee: this.state.coursefee
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
            this.componentDidMount()
            this.setState({coursename:''})
          this.setState({courseid:''})
          this.setState({coursefee:''})
            
            swal({
              title: "Success!",
              text: "Course Fees Created Successfully",
              icon: "success",
            });
            
        })

       
        .catch((err) => { console.log(err)});
      
      }


      render() {
          console.log(this.state)
        return (
            <div class='overAll'>
               
           
           <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
           
               <label className="lab"> Course Name </label>
               <div className="master-form-group">
               <input type="coursename" value={this.state.coursename} placeholder="Course Name" onChange={(e)=>{this.coursenameChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">Course Id </label>
               <div className="master-form-group">
               <input type="courseid" value={this.state.courseid} placeholder="courseid" onChange={(e)=>{this.courseidChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">course Fees </label>
               <div className="master-form-group">
               <input type="coursefee" value={this.state.coursefee} placeholder="coursefee" onChange={(e)=>{this.coursefeeChange(e)}} />
               </div>
               </div>
               </div>
               <SubmitButton />
             </form>
             </div>
            
<div className="master-createuser">
        <table>
          <thead>
            <tr>
              <th>Course ID</th>
              <th>Course Name</th>
              <th>Course Fees</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.courseid}</td>
                  <td>{user.coursename}</td>
                  <td>{user.coursefee}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No Course Fees</td>
              </tr>
            )}
          </tbody>
        </table>
        );
      </div>

             
             </div>
            

          
        );
      } 
}





export default Createfees;