import React from "react";
import '../subpage/App.css'
import axios from 'axios'; 
import '../subpage/searchstudent.css';


const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Searchstudent extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         studentid: '',
         name: '',
         course:'',
         data:[]
        };
        this.nameChange = this.nameChange.bind(this);
       
      }

      nameChange(event) {
        this.setState({ name: event.target.value});
      if( event.target.value=='')
      {
        this.setState({name:''})
        this.setState({studentid:''})
        this.setState({course:''})
      }
      }
      toggleshow() {
        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("h");
        node.classList.toggle('hide')
      }
   

      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchstudent',  
          data: {  
            name: this.state.name,  
            
           
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
            this.setState({ name: res.data[0].name});
            this.setState({ studentid: res.data[0].studentid});
            this.setState({ course: res.data[0].course});
            this.setState({data:res.data})
            
        })

       
        .catch((err) => { console.log(err)});
       
      }


      render() {
          console.log(this.state)
          console.log(this.state.data)
        return (
            <div class='overAll'>
            
            <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
                <label className="lab">Student Name </label>
               <div className="master-form-group">
               <input type="text" value={this.state.name} placeholder="Name" onChange={(e)=>{this.nameChange(e)}} />
               </div>
               <SubmitButton />
               </div>
              
                <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Course </th>
            </tr>
          </thead>
          <tbody>
            
            {this.state.data.length > 0 ? (
                <tr key={this.state.data[0].studentid}>
                  <td>{this.state.data[0].studentid}</td>
                  <td>{this.state.data[0].name}</td>
                  <td>{this.state.data[0].course}</td>
                </tr>
              
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
        
     
      
               
               
             </form>
             </div>
             </div>
        );
        
      } 
}





export default Searchstudent;