import React from "react";

import '../subpage/App.css'
import axios from 'axios'; 
import ReactDOM from 'react-dom';
import swal from 'sweetalert';
import '../subpage/createteacher.css';



const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Createteacher extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         name: '',
         teacherid: '',
         course:'',
         data:[]
        };
        this.nameChange = this.nameChange.bind(this);
        this.teacherididChange = this.teacheridChange.bind(this);
        
      }

      nameChange(event) {
        this.setState({ name: event.target.value});
      }
      teacheridChange(event) {
        this.setState({ teacherid: event.target.value});
      }
      courseChange(event) {
          console.log(event.target.value)
        this.setState({ course: event.target.value});
      }
      toggleshow() {
     

        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("ak");
       
        node.classList.toggle('hide')
      }
      componentDidMount(){
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchallteachers',  
          data: {  
           
          }  
        }).then((res) => {
          console.log(res);
          this.setState({data:res.data})
          
        })

       
        .catch((err) => { console.log(err)});
       
      }



      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/saveteacher',  
          data: {  
            name: this.state.name,  
            teacherid: this.state.teacherid,
            course: this.state.course
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
            this.componentDidMount()
            this.setState({name:''})
          this.setState({teacherid:''})
          this.setState({course:''})
          
            swal({
              title: "Success!",
              text: "Teacher Created Successfully",
              icon: "success",
            });
            
        })

       
        .catch((err) => { console.log(err)});
       
      }


      render() {
          console.log(this.state)
        return (
            <div class='overAll'>
            
            <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
           
               <label className="lab"> Name </label>
               <div className="master-form-group">
               <input type="text" value={this.state.name} placeholder="Teachername" onChange={(e)=>{this.nameChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">Teacher Id </label>
               <div className="master-form-group">
               <input type="teacherid" value={this.state.teacherid} placeholder="Teacherid" onChange={(e)=>{this.teacheridChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">course </label>
               <div className="master-form-group">
               <input type="course" value={this.state.course} placeholder="Course" onChange={(e)=>{this.courseChange(e)}} />
               </div>
               </div>
               </div>
              
               <SubmitButton />
             </form>
             </div>

            
              <div className="master-createuser">
        <table>
          <thead>
            <tr>
              <th>Teacher ID</th>
              <th>Teacher Name</th>
              <th>Course Name</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.teacherid}</td>
                  <td>{user.name}</td>
                  <td>{user.course}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No Teacher</td>
              </tr>
            )}
          </tbody>
        </table>
        );

          
             </div>
             </div>
          
          
        );
      } 
}



export default Createteacher;