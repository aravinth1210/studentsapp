import React from "react";
import '../subpage/App.css'
import axios from 'axios'; 
import '../subpage/searchcoursefee.css';



const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Searchcoursefee extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         courseid: '',
         coursename: '',
         coursefee:'',
         data:[]
        };
        this.coursenameChange = this.coursename.bind(this);
        
      }

      coursename(event) {
        this.setState({ coursename: event.target.value});
        if( event.target.value=='')
      {
        this.setState({coursename:''})
        this.setState({courseid:''})
        this.setState({coursefee:''})
      }
      }

      toggleshow() {
        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("g");
        node.classList.toggle('hide')
      }
    

      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchfees',  
          data: {  
            coursename: this.state.coursename,  
            
           
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
            this.setState({ courseid: res.data[0].courseid});
            this.setState({ coursename: res.data[0].coursename});
            this.setState({ coursefee: res.data[0].coursefee});
            this.setState({data:res.data})
            
        })

       
        .catch((err) => { console.log(err)});
        
      }


      render() {
          console.log(this.state)
          console.log(this.state.data)
        return (
            <div class='overAll'>
           
             <div class="container">

            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
                <label className="lab"> Name</label>
               <div className="master-form-group">
               <input type="text" value={this.state.coursename} placeholder="CourseName" onChange={(e)=>{this.coursenameChange(e)}} />
               </div>
               <SubmitButton />
               </div>
              
               <table>
          <thead>
            <tr>
              <th>Course ID</th>
              <th>Course Name</th>
              <th>Course Fees</th>
            </tr>
          </thead>
          <tbody>
            
            {this.state.data.length > 0 ? (
                <tr key={this.state.data[0].courseid}>
                  <td>{this.state.data[0].courseid}</td>
                  <td>{this.state.data[0].coursename}</td>
                  <td>{this.state.data[0].coursefee}</td>
                </tr>
              
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
        
     
               
               
             </form>
             </div>
             </div>
        );
        
      } 
}


export default Searchcoursefee;