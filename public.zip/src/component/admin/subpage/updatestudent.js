import React from "react";
import '../subpage/App.css'
import axios from 'axios'; 
import swal from 'sweetalert';
import '../subpage/updatestudent.css';

const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

class Updatestudent extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         studentid: '',
         name: '',
         course:'',
         data:[]
        };
        this.studentidChange = this.studentidChange.bind(this);
       
        this.aktest=this.aktest.bind(this);
        this.updateonClick=this.updateonClick.bind(this);
      }

      studentidChange(event) {
        this.setState({ studentid: event.target.value});
      }
      nameChange(event) {
        this.setState({ name: event.target.value});
      }
      courseChange(event) {
        this.setState({ course: event.target.value});
      }
      toggleshow() {
        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("j");
        node.classList.toggle('hide')
      }
      
    componentDidMount(){
      axios({  
        method: 'post',  
        url: 'http://127.0.0.1:5000/fetchallstudents',  
        data: {  
         
        }  
      }).then((res) => {
        console.log(res);
        this.setState({data:res.data})
      
      })
    }


    handleSubmit(e) {
      
      console.log(e)
      console.log("form has been submitted: ");
     
      axios({  
        method: 'post',  
        url: 'http://127.0.0.1:5000/fetchstudents',  
        data: {  
          studentid: e,  
          
         
        }  
      }).then((res) => {
        console.log(res);
        if(res.data.error)
          alert("Enter correct credentials")
          this.setState({ name: res.data[0].name});
          this.setState({ studentid: res.data[0].studentid});
          this.setState({ course: res.data[0].course});
          
      })

     
    }

    
    updateonClick() {
     
      console.log("form has been submitted: ");
      
      axios({  
        method: 'post',  
        url: 'http://127.0.0.1:5000/updatestudent',  
        data: {  
          name: this.state.name,  
          course: this.state.course,
          studentid: this.state.studentid,
          
        
        }  
      }).then((res) => {
        console.log(res);
        if(res.data.error)
          alert("Enter correct credentials")
                  this.componentDidMount()
          this.setState({name:''})
          this.setState({studentid:''})
          this.setState({course:''})
          
          swal({
            title: "Success!",
            text: "Student Updated Successfully",
            icon: "success",
          });

      })

     
      .catch((err) => { console.log(err)});
         }


      
        
      aktest() {
        console.log('justcheckin')
     
    }

      render() {
          console.log(this.state)
          var that =this
        return (
          
            
              <div className='overAll'>
              <div className="container">
           
            
            <form >  
              
          <div className="row justify-content-center">
             
              <div className="col-6"> 
               <label className="lab">Edit Name </label>
               <div className="master-form-group">
               <input type="name" value={this.state.name} placeholder="name" onChange={(e)=>{this.nameChange(e)}} /> </div>
               </div>
               
              
              
              <div className="col-6">
               <label className="lab">Course </label>
               <div className="master-form-group">
               <input type="course" value={this.state.course} placeholder="course" onChange={(e)=>{this.courseChange(e)}} /> </div>
               </div>
               
               
               <div className="master-form-group">
               <button type="submit"className="master-submit-btn" onClick={this.updateonClick}>Update Student</button>
               </div>
              
               
               
              </div>
             </form>
            
 <div className="master-createuser1">
        <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Course</th>
              <th>Edit</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.studentid}</td>
                  <td>{user.name}</td>
                  <td>{user.course}</td>
                  <td> <button type="submit"className="master-submit-btn" sid={user.studentid} onClick={(e)=>{that.handleSubmit(user.studentid)}}>Edit</button></td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table> 
        
      </div>
      </div>
      </div>
    

    );
  }
}




export default Updatestudent;