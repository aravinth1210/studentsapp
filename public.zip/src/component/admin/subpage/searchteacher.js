import React from "react";
import '../subpage/App.css'
import axios from 'axios'; 
import '../subpage/searchteacher.css';


const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Searchteacher extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         teacherid: '',
         name: '',
         course:'',
         data:[]
        };
        this.nameChange = this.nameChange.bind(this);
       
      }

      nameChange(event) {
        this.setState({ name: event.target.value});
        if( event.target.value=='')
      {
        this.setState({name:''})
        this.setState({teacherid:''})
        this.setState({course:''})
      }
      }
      toggleshow() {
        var aknode = document.getElementsByClassName("totalhide");
      for(var i=0;i<aknode.length;i++){
        aknode[i].classList.add('hide')
    }
        var node = document.getElementById("i");
        node.classList.toggle('hide')
      }
    

      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/fetchteacher',  
          data: {  
            name: this.state.name,  
            
           
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
            this.setState({ teacherid: res.data[0].teacherid});
            this.setState({ name: res.data[0].name});
            this.setState({ course: res.data[0].course});
            this.setState({data:res.data})
            
        })

       
        .catch((err) => { console.log(err)});
       
      }


      render() {
          console.log(this.state)
          console.log(this.state.data)
        return (
            <div class='overAll'>
           
            <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
                <label className="lab">Teacher Name </label>
               <div className="master-form-group">
               <input type="text" value={this.state.name} placeholder="name" onChange={(e)=>{this.nameChange(e)}} />
               </div>
               


               <SubmitButton />
               </div>
               
               
               <table>
          <thead>
            <tr>
              <th>Teacher ID</th>
              <th>Teacher Name</th>
              <th>Course </th>
            </tr>
          </thead>
          <tbody>
            
            {this.state.data.length > 0 ? (
                <tr key={this.state.data[0].teacherid}>
                  <td>{this.state.data[0].teacherid}</td>
                  <td>{this.state.data[0].name}</td>
                  <td>{this.state.data[0].course}</td>
                </tr>
              
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
        
    
      
               
               
             </form>
             </div>
             </div>
        );
        
      } 
}


              



export default Searchteacher;