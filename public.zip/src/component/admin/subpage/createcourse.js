import React from "react";

import '../subpage/App.css'
import axios from 'axios'; 
import swal from 'sweetalert';
import '../subpage/createcourse.css';


const SubmitButton = (props) => {
    return (
    <div className="master-form-group master-center">
    <button type="submit"className="master-submit-btn">Submit</button>
    </div>
    )
  }

  

class Createcourse extends React.Component { 

    constructor(props) {
        super(props);
        this.state = {
         coursename: '',
         courseid: '',
         courseduration:'',
         data:[]
        };
        this.coursenameChange = this.coursenameChange.bind(this);
        this.courseidChange = this.courseidChange.bind(this);
       
      }

      coursenameChange(event) {
        this.setState({ coursename: event.target.value});
      }
      courseidChange(event) {
        this.setState({ courseid: event.target.value});
      }
      coursedurationChange(event) {
          console.log(event.target.value)
        this.setState({ courseduration: event.target.value});
      }
      toggleshow() {
       
        var aknode = document.getElementsByClassName("totalhide");
        for(var i=0;i<aknode.length;i++){
          aknode[i].classList.add('hide')
      }
         
        var node = document.getElementById("gan");
        
        node.classList.toggle('hide')
      }
componentDidMount(){

      axios({  
        method: 'post',  
        url: 'http://127.0.0.1:5000/fetchallcourses',  
        data: {  
          
        }  
      }).then((res) => {
        console.log(res);
      
          this.setState({data:res.data})
      })

     
      .catch((err) => { console.log(err)});
     
    }




      handleSubmit(event) {
        event.preventDefault();
        console.log("form has been submitted: ");
       
        axios({  
          method: 'post',  
          url: 'http://127.0.0.1:5000/savecourse',  
          data: {  
            coursename: this.state.coursename,  
            courseid: this.state.courseid,
            courseduration: this.state.courseduration
          }  
        }).then((res) => {
          console.log(res);
          if(res.data.error)
            alert("Enter correct credentials")
          this.componentDidMount()
          this.setState({coursename:''})
          this.setState({courseid:''})
          this.setState({courseduration:''})
          
          swal({
            title: "Success!",
            text: "Course Created Successfully",
            icon: "success",
          });
          
        })
        .catch((err) => { console.log(err)});
      }


      render() {
          console.log(this.state)
        return (
            <div class='overAll'>
            
             <div class="container">
            <form onSubmit={(e)=>{this.handleSubmit(e)}}>  
            <div class="row justify-content-center">
              <div class="col-4">
           
               <label className="lab"> Course Name </label>
               <div className="master-form-group">
               <input type="coursename" value={this.state.coursename} placeholder="Course Name" onChange={(e)=>{this.coursenameChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">Course Id </label>
               <div className="master-form-group">
               <input type="courseid" value={this.state.courseid} placeholder="courseid" onChange={(e)=>{this.courseidChange(e)}} />
               </div>
               </div>
               <div class="col-4">
               <label className="lab">course Duration </label>
               <div className="master-form-group">
               <input type="courseduration" value={this.state.courseduration} placeholder="courseduration" onChange={(e)=>{this.coursedurationChange(e)}} />
               </div>
               </div></div>
               <SubmitButton />
             </form>
             </div>
             <div className="master-createuser">
        <table>
          <thead>
            <tr>
              <th>Course ID</th>
              <th>Course Name</th>
              <th>Course Duration</th>
            </tr>
          </thead>
          <tbody>
            {this.state.data.length > 0 ? (
              this.state.data.map(user => (
                <tr key={user.id}>
                  <td>{user.courseid}</td>
                  <td>{user.coursename}</td>
                  <td>{user.courseduration}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3}>No Course </td>
              </tr>
            )}
          </tbody>
        </table>
        );
      </div>

             
             </div>
            

          
        );
      } 
}


export default Createcourse;