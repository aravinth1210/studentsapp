import React, { Component } from 'react';
import '../footer/footer.css'



class Footer extends React.Component {
  render() {
    return (
      <div className="footer">
        <p>www.codeWork.com@2022</p>
      </div>
    );
  }
}

export default Footer;