import React from "react";
import axios from 'axios';

import Footer from '../footer/footer';

import '../student/student.css';
import { NavLink } from "react-router-dom";



class Student extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      studentid: '',
      course: '',
      data:[]
    };

  }


  logoutonClick() {
    localStorage.clear();
    window.location.href = "Login"
  }

  componentDidMount() {
    console.log(localStorage.getItem('username'))
    console.log(localStorage.getItem("isloogedin"))
    if (localStorage.getItem("isloogedin") != "true") {
      window.location.href = "Login"
    }
    axios({
      method: 'post',
      url: 'http://127.0.0.1:5000/fetchstudentbyname',
      data: {
        name: localStorage.getItem('username')
      }
    }).then((res) => {
      console.log(res.data[0].username);
      if (res.data.error)
        alert("Enter correct credentials")
      this.setState({ name: res.data[0].name });
      this.setState({ studentid: res.data[0].studentid });
      this.setState({ course: res.data[0].course });
      this.setState({data:res.data})

    })

      
      .catch((err) => { console.log(err) });
  }


  render() {  
           console.log(this.state.data)
    return (
      <div>
        <div>
          <nav className="navbar bd-col">
            <a href="#" className="navbar-logo"
            ><i class="material-icons"></i>Code<i class="fab fa-codepen"></i></a>

            <ul className="navbar-links pd-l">
              <li className="navbar-dropdown">
                <NavLink to="/" onClick={this.logoutonClick} exact activeStyle={{ color: '#2a6496' }}>Logout</NavLink>
              </li>

              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4510menu-item menu-item-type-custom menu-item-object-custom menu-item-4510 gdlr-normal-menu"><a title="Facebook" href="https://www.facebook.com/Timezonehostelhollywood/"><i class="fa fa-facebook-square"></i></a></li>
              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4511menu-item menu-item-type-custom menu-item-object-custom menu-item-4511 gdlr-normal-menu"><a title="Twitter" href="https://twitter.com/timezonehostel"><i class="fa fa-twitter-square"></i></a></li>
              <li className="menu-item menu-item-type-custom menu-item-object-custom menu-item-4512menu-item menu-item-type-custom menu-item-object-custom menu-item-4512 gdlr-normal-menu"><a title="Instagram" href="https://www.instagram.com/Timezonehostelhollywood/"><i class="fa fa-instagram"></i></a></li>

            </ul>
          </nav>
        </div>
        <div class="container">
        <div class="row justify-content-center">
              <div class="col-4">
               </div>
          <div className="master-createuser">
          <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Course </th>
            </tr>
          </thead>
          <tbody>
            
            {this.state.data.length > 0 ? (
                <tr key={this.state.data[0].studentid}>
                  <td>{this.state.data[0].studentid}</td>
                  <td>{this.state.data[0].name}</td>
                  <td>{this.state.data[0].course}</td>
                </tr>
              
            ) : (
              <tr>
                <td colSpan={3}>No users</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
        </div>
        {/* <Footer /> */}
      </div>
      </div>
    );
  }
}


export default Student;
