import { Route, Switch} from 'react-router-dom';
import './App.css';
import Admin from './component/admin/admindetails';
import Login from './component/login/login';
import Student from './component/student/studentdetails';
import Teacher from './component/teacher/teacherdetails';


const App = () => (
  <Switch>
    
    <Route exact path ="/login" component={Login} ></Route>
    
    <Route path ="/admin" component={Admin}></Route>
    <Route path ="/student" component={Student}></Route>
    <Route path ="/teacher" component={Teacher}></Route>
    <Route exact path ="*" component={Login} ></Route>
   
    </Switch>
);


export default App;
